<?php

include "Translit.class.php";

$translit = new Translit();
echo $translit->Transliterate('Филип Аврамовић');

?>
